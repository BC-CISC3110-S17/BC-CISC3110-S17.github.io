#include <iostream>


// NOTE: maybe do this in two programs...?

int main() {
    const int SIZE=10;
    int *max, *min, // will eventually point to min and max elements
        *curr;      // pointer to traverse the array

    int array[SIZE] = {4, 3, 10, 5, 7, -4, 11, 3, 1, 9};

    max = min = array;   // first element is a candidate to be max/min

    curr = array+1; //next candidate is second element

/* iterate through array elements, updating max and min as we find
   larger/smaller values. */

    while (curr >= array) {
        // std::cout << "looking at " << *curr << std::endl; // for debugging
        if (*curr > *max) {
            max = curr;
        }

        if (*curr < *min) {
            min = curr;
        }
        curr = curr + 1;
    }

    /* output results */

    std::cout << "Minimum value is " << *min << std::endl;
    std::cout << "Maximum value is " << *max << std::endl;

}
