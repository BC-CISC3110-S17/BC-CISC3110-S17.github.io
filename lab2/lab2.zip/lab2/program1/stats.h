#ifndef STATS_H
#define STATS_H

void do_stats (double arr[], int size, double* mean, double* stddev);

#endif
