#include "stats.h"

#include <iostream>

void do_stats (double arr[], int size, double* mean, double* stddev) {

    double sum = 0.0;

    for (int i=0; i < size; i++) {
        sum+=arr[i];
     }

    *mean=sum/size;
    double sumdiff = 0.0;
    for (int i=0; i< size; i++ ) {
        sumdiff += (arr[i] - *mean) * (arr[i] - *mean);
    }
    *stddev = sumdiff/size;

}
