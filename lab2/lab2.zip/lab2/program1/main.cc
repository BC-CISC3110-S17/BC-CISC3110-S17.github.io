#include <iostream>


#include "stats.h"

using namespace std;

int main()
{
    const int SIZE = 10;
    cout << "Please enter " << SIZE << " numbers: ";

    double inputVals[SIZE];
    double mean,
        stdDev;

    for (int i=0; i < SIZE; i++) {
        std::cin >> inputVals[i];
    }

    do_stats(inputVals, SIZE, &mean, &stdDev);

    cout << "The average is " << mean << endl;
    cout << "The standard deviation is " << stdDev << endl;

}
