#ifndef BOARD_H
#define BOARD_H

void playAMove();
void display();
void checkForWin();

#endif
