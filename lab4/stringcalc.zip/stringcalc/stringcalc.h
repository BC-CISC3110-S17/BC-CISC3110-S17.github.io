#ifndef STRINGCALC_H
#define STRINGCALC_H
#include <string>
class StringCalc {
	public:

	int add(std::string numbers);
};

#endif
